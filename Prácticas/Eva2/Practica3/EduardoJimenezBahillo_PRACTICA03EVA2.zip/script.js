setTimeout(
    function() { //Función anónima que redirige a duckduckgo
        location.href = "https://duckduckgo.com/";
    },
    5000 //Se ejecutará después de 5 segundos
);